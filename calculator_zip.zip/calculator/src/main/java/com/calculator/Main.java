package com.calculator;

public class Main {

    static void main(){
        WebController webcontroller = new WebController();
        IO.print(webcontroller.calculate(10 , 20 , "+"));
    }

}

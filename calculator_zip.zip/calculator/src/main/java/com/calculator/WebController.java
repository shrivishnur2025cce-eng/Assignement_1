package com.calculator;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @PostMapping("/calculate")
    int calculate(int a , int  b , String operation){
        switch (operation){
            case "+"->{
                return a + b;
            }
            case "-"->{
                return a - b;
            }

            case "*"->{
                return a * b;
            }

            case "/"->{
                return a / b;
            }
        }
        return 0;
    }
}

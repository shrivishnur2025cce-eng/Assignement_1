package com.example.project_leap_25cc058_sujith.controller;

import com.example.project_leap_25cc058_sujith.model.Student;
import com.example.project_leap_25cc058_sujith.services.WebService;
import com.example.project_leap_25cc058_sujith.services.impl.WebServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class WebController {
    @Autowired
    private WebService webService;

    @PostMapping
    public Student addStudent(@RequestBody Student student){
    return webService.saveStudent(student);
    }
}



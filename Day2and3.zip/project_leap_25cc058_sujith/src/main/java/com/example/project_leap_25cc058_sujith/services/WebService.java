package com.example.project_leap_25cc058_sujith.services;

import com.example.project_leap_25cc058_sujith.model.Student;

import java.util.List;

public interface WebService {
    Student saveStudent(Student student);
    void deleteStudent(Long id);
    List<Student> readStudents();
    Student updateStudent(Student student);
}

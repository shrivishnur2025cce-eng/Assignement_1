package com.example.project_leap_25cc058_sujith.repository;

import com.example.project_leap_25cc058_sujith.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface WebRepository extends JpaRepository<Student,Long> {


}
